import { GoogleGenAI } from "@google/genai";
import { Business, GeolocationCoordinates } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

export const findBusinesses = async (
  businessType: string,
  district: string,
  city: string,
  location: GeolocationCoordinates | null
): Promise<Business[]> => {
  try {
    // FIX: Use system instruction for better prompting and separate user content.
    const userPrompt = `${district}, ${city} bölgesindeki ${businessType} işletmelerini listele.`;
    const systemInstruction = `Yanıt olarak SADECE geçerli bir JSON dizisi döndür. JSON objeleri 'name' ve 'phoneNumber' alanlarını içermelidir. Başka HİÇBİR metin, açıklama veya markdown formatı ekleme. Eğer hiç sonuç bulamazsan, sadece boş bir dizi [] döndür.`;
    
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: userPrompt,
      config: {
        systemInstruction,
        tools: [{ googleMaps: {} }],
        toolConfig: location ? {
          retrievalConfig: {
            latLng: {
              latitude: location.latitude,
              longitude: location.longitude,
            },
          },
        } : undefined,
      },
    });

    const responseText = response.text;
    
    // FIX: Add robust JSON extraction to handle markdown code blocks.
    let jsonArrayString = responseText.trim();
    const markdownMatch = jsonArrayString.match(/```(?:json)?\s*([\s\S]*?)\s*```/);
    if (markdownMatch && markdownMatch[1]) {
      jsonArrayString = markdownMatch[1].trim();
    }

    const startIndex = jsonArrayString.indexOf('[');
    const endIndex = jsonArrayString.lastIndexOf(']');

    if (startIndex === -1 || endIndex === -1) {
      console.warn('API response did not contain a JSON array.', { response: responseText });
      return [];
    }

    jsonArrayString = jsonArrayString.substring(startIndex, endIndex + 1);
    let parsedBusinesses: Omit<Business, 'mapsUri'>[];

    try {
        parsedBusinesses = JSON.parse(jsonArrayString);
    } catch (e) {
        console.error('Failed to parse extracted JSON from API response.', { error: e, extractedString: jsonArrayString, fullResponse: responseText });
        throw new Error("API'den gelen yanıt işlenemedi. Geçersiz format.");
    }
    
    if (!Array.isArray(parsedBusinesses)) {
        console.warn('Parsed JSON from API is not an array.', { parsedData: parsedBusinesses });
        return [];
    }
    
    const groundingData = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
    // Fix: Explicitly type the return value of the map function to `Business | null`.
    // This ensures TypeScript correctly infers the type for the subsequent filter operation.
    const businessesWithMaps = parsedBusinesses.map((business): Business | null => {
      if (!business || typeof business.name !== 'string' || typeof business.phoneNumber !== 'string') {
        return null;
      }
      
      const groundInfo = groundingData?.find(g => 
        g.maps && g.maps.title && business.name.toLowerCase().includes(g.maps.title.toLowerCase())
      );
      return {
        ...business,
        mapsUri: groundInfo?.maps?.uri,
      };
    }).filter((b): b is Business => b !== null);

    return businessesWithMaps;

  } catch (error) {
    console.error("Error calling Gemini API:", error);
    if (error instanceof Error) {
        if (error.message.includes('"code":429') || error.message.includes('RESOURCE_EXHAUSTED')) {
            throw new Error(`API kota limitine ulaşıldı. Lütfen bir süre bekleyip tekrar deneyin veya fatura detaylarınızı kontrol edin.`);
        }
        throw new Error(`API Hatası: ${error.message}`);
    }
    throw new Error("Bilinmeyen bir API hatası oluştu.");
  }
};