
import React from 'react';
import { Business } from '../types';

interface BusinessCardProps {
  business: Business;
}

const ExternalLinkIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="currentColor"
    className={className}
  >
    <path
      fillRule="evenodd"
      d="M19.904 4.096a.75.75 0 01.75.75v8.5a.75.75 0 01-1.5 0V6.56L9.03 17.69a.75.75 0 01-1.06-1.06L18.09 5.5H9.84a.75.75 0 010-1.5h10.064z"
      clipRule="evenodd"
    />
  </svg>
);

const BusinessCard: React.FC<BusinessCardProps> = ({ business }) => {
  const cardContent = (
    <div className="flex justify-between items-center w-full">
      <div>
        <h3 className="font-bold text-lg text-cyan-400">{business.name}</h3>
        <p className="text-slate-400">{business.phoneNumber}</p>
      </div>
      {business.mapsUri && <ExternalLinkIcon className="w-6 h-6 text-slate-500" />}
    </div>
  );

  if (business.mapsUri) {
    return (
      <a
        href={business.mapsUri}
        target="_blank"
        rel="noopener noreferrer"
        className="block bg-slate-800 p-4 rounded-lg shadow-md hover:bg-slate-700/80 transition-all duration-200"
      >
        {cardContent}
      </a>
    );
  }

  return (
    <div className="bg-slate-800 p-4 rounded-lg shadow-md">
      {cardContent}
    </div>
  );
};

export default BusinessCard;
