
export interface Business {
  name: string;
  phoneNumber: string;
  mapsUri?: string;
}

export interface GeolocationCoordinates {
  latitude: number;
  longitude: number;
}
