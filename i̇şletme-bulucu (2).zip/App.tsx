import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Business, GeolocationCoordinates } from './types';
import { findBusinesses } from './services/geminiService';
import { provinces } from './data/cities';
import BusinessCard from './components/BusinessCard';

const Spinner: React.FC = () => (
    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
    </svg>
);

const App: React.FC = () => {
    const [businessType, setBusinessType] = useState('Kırtasiye');
    const [isScanning, setIsScanning] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [savedBusinesses, setSavedBusinesses] = useState<Business[]>([]);
    const [isCopied, setIsCopied] = useState(false);
    const [scanStatus, setScanStatus] = useState('Otomatik tarama için hazır.');
    const scanInterrupted = useRef(false);

    useEffect(() => {
        try {
            const storedBusinesses = localStorage.getItem('savedBusinesses');
            if (storedBusinesses) {
                setSavedBusinesses(JSON.parse(storedBusinesses));
            }
        } catch (err) {
            console.error("Failed to load businesses from localStorage", err);
        }
    }, []);

    const getUserLocation = (): Promise<GeolocationCoordinates | null> => {
        return new Promise((resolve) => {
            if (!navigator.geolocation) { resolve(null); return; }
            const timeoutId = setTimeout(() => resolve(null), 5000);
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    clearTimeout(timeoutId);
                    resolve({
                        latitude: position.coords.latitude,
                        longitude: position.coords.longitude,
                    });
                },
                () => { clearTimeout(timeoutId); resolve(null); }
            );
        });
    };

    const startScan = useCallback(async () => {
        if (!businessType.trim()) {
            setError("Lütfen aranacak bir işletme türü girin.");
            return;
        }
        setIsScanning(true);
        scanInterrupted.current = false;
        setError(null);
        
        const location = await getUserLocation();

        for (let i = 0; i < provinces.length; i++) {
            const province = provinces[i];

            for (let j = 0; j < province.districts.length; j++) {
                const district = province.districts[j];

                if (scanInterrupted.current) {
                    setScanStatus('Tarama kullanıcı tarafından durduruldu.');
                    setIsScanning(false);
                    return;
                }

                setScanStatus(`Taranıyor: ${district}, ${province.name} | İl: ${i + 1}/${provinces.length}`);
                
                try {
                    const results = await findBusinesses(businessType, district, province.name, location);
                    
                    const filteredResults = results.filter(b => b.phoneNumber && (b.phoneNumber.startsWith('05') || b.phoneNumber.startsWith('5')));

                    if (filteredResults.length > 0) {
                        setSavedBusinesses(prevSaved => {
                            const existingPhoneNumbers = new Set(prevSaved.map(b => b.phoneNumber));
                            const newUniqueBusinesses = filteredResults.filter(b => !existingPhoneNumbers.has(b.phoneNumber));
                            
                            if (newUniqueBusinesses.length > 0) {
                                const updatedList = [...prevSaved, ...newUniqueBusinesses];
                                localStorage.setItem('savedBusinesses', JSON.stringify(updatedList));
                                return updatedList;
                            }
                            return prevSaved;
                        });
                    }
                } catch (err) {
                    console.error(`Error searching for ${district}, ${province.name}:`, err);
                    const errorMessage = err instanceof Error ? err.message : 'Bilinmeyen bir hata oluştu.';
                    setError(errorMessage);
                    setScanStatus('Kritik bir hata nedeniyle tarama durduruldu.');
                    setIsScanning(false);
                    return;
                }
                
                // Wait for 5 seconds between each district request to avoid rate limiting
                const nextDistrict = province.districts[j + 1];
                const nextTarget = nextDistrict ? `${nextDistrict}, ${province.name}` : `Sıradaki il: ${provinces[i+1]?.name || 'Yok'}`;
                setScanStatus(`API limiti için 5 saniye bekleniyor... | Sırada: ${nextTarget}`);
                await new Promise(resolve => setTimeout(resolve, 5000));
            }

            if (scanInterrupted.current) {
                setScanStatus('Tarama kullanıcı tarafından durduruldu.');
                setIsScanning(false);
                return;
            }

            if (i < provinces.length - 1) {
                // After a province is done, wait 20 seconds before starting the next one
                setScanStatus(`${province.name} tamamlandı. 20 saniye bekleniyor... | Sırada: ${provinces[i+1]?.name || 'Yok'}`);
                await new Promise(resolve => setTimeout(resolve, 20000));
            }
        }
        
        setScanStatus(`Tarama tamamlandı. ${provinces.length} ilin tamamı tarandı.`);
        setIsScanning(false);
    }, [businessType]);

    const stopScan = () => {
        scanInterrupted.current = true;
        setScanStatus('Tarama durduruluyor...');
    };

    const handleToggleScan = () => {
        if (isScanning) {
            stopScan();
        } else {
            startScan();
        }
    };

    const handleCopyToClipboard = () => {
        const textToCopy = savedBusinesses.map(b => `${b.name}\t${b.phoneNumber}`).join('\n');
        navigator.clipboard.writeText(textToCopy).then(() => {
            setIsCopied(true);
            setTimeout(() => setIsCopied(false), 2000);
        });
    };

    const handleClearAll = () => {
        localStorage.removeItem('savedBusinesses');
        setSavedBusinesses([]);
    };

    return (
        <div className="min-h-screen bg-slate-900 text-slate-200 font-sans p-4 md:p-8">
            <div className="max-w-4xl mx-auto">
                <header className="text-center mb-8">
                    <h1 className="text-4xl md:text-5xl font-bold text-cyan-400 tracking-tight">İşletme Bulucu</h1>
                    <p className="text-slate-400 mt-2">Türkiye genelinde istediğiniz işletme türünü ilçe ilçe bulun.</p>
                </header>

                <main>
                    <div className="bg-slate-800/50 p-6 rounded-lg shadow-2xl mb-8 border border-slate-700">
                        <div className="mb-4">
                            <label htmlFor="businessType" className="block text-sm font-medium text-slate-300 mb-2">Aranacak İşletme Türü</label>
                            <input
                                id="businessType"
                                type="text"
                                value={businessType}
                                onChange={(e) => setBusinessType(e.target.value)}
                                disabled={isScanning}
                                placeholder="Örn: Kırtasiye, Market, Fırın..."
                                className="w-full bg-slate-900/50 border border-slate-600 rounded-md py-2 px-3 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500 disabled:opacity-50"
                            />
                        </div>
                        <div className='text-center mb-4'>
                           <p className='text-lg font-medium text-slate-300'>Tarama Durumu</p>
                           <p className='text-cyan-400 h-6 truncate' title={scanStatus}>{scanStatus}</p>
                        </div>
                        <button
                            onClick={handleToggleScan}
                            disabled={!businessType.trim()}
                            className={`w-full flex items-center justify-center text-white font-bold py-3 px-4 rounded-md disabled:cursor-not-allowed disabled:bg-slate-600 transition-colors duration-300 ${isScanning ? 'bg-red-600 hover:bg-red-700' : 'bg-cyan-600 hover:bg-cyan-700'}`}
                        >
                            {isScanning ? <><Spinner /> Taramayı Durdur</> : 'Tüm Türkiye için Taramayı Başlat'}
                        </button>
                    </div>

                    {error && <div className="bg-red-500/20 text-red-300 p-4 rounded-md mb-8 text-center border border-red-500">{error}</div>}
                    
                    {savedBusinesses.length > 0 && (
                         <div className="bg-slate-800/50 p-6 rounded-lg shadow-2xl border border-slate-700">
                             <div className="flex justify-between items-center mb-4 border-b-2 border-slate-700 pb-2">
                                <h2 className="text-2xl font-bold text-slate-300">Kaydedilen İşletmeler</h2>
                                <div>
                                    <span className="bg-slate-700 text-cyan-400 font-bold text-sm px-3 py-1 rounded-full mr-4">{savedBusinesses.length}</span>
                                    <button
                                        onClick={handleClearAll}
                                        className="text-red-400 hover:text-red-300 text-sm font-semibold"
                                    >
                                        Tümünü Temizle
                                    </button>
                                </div>
                             </div>
                             <div className="max-h-96 overflow-y-auto space-y-3 pr-2">
                                {savedBusinesses.map((business, index) => (
                                    <BusinessCard key={`${business.phoneNumber}-${index}`} business={business} />
                                ))}
                             </div>
                             <button
                                onClick={handleCopyToClipboard}
                                className={`w-full mt-4 font-bold py-2 px-4 rounded transition-colors duration-200 ${isCopied ? 'bg-green-600 hover:bg-green-700' : 'bg-slate-600 hover:bg-slate-500'}`}
                             >
                                {isCopied ? 'Kopyalandı!' : 'Tümünü Panoya Kopyala'}
                             </button>
                         </div>
                    )}
                </main>
            </div>
        </div>
    );
};

export default App;